document.addEventListener("DOMContentLoaded", function () {

    // 1. MOBILE NAVIGATION MENU
    const nav = document.querySelector("nav");

    if (nav) {
        let menuButton = document.querySelector(".menu-toggle");

        if (!menuButton) {
            menuButton = document.createElement("button");
            menuButton.textContent = "☰ Menu";
            menuButton.className = "menu-toggle";
            menuButton.type = "button";
            menuButton.setAttribute("aria-expanded", "false");

            nav.parentNode.insertBefore(menuButton, nav);
        }

        menuButton.addEventListener("click", function () {
            const isOpen = nav.classList.toggle("active");
            menuButton.setAttribute("aria-expanded", String(isOpen));
        });

        // 2. HIGHLIGHT ACTIVE PAGE
        const currentPage = location.pathname.split("/").pop().toLowerCase();

        nav.querySelectorAll("a").forEach(function (link) {
            const linkPage = new URL(link.href).pathname
                .split("/").pop().toLowerCase();

            if (currentPage === linkPage) {
                link.classList.add("active-link");
                link.setAttribute("aria-current", "page");
            }
        });
    }

    // 3. SERVICE SEARCH
    const serviceItems = document.querySelectorAll(".search-item");

    if (serviceItems.length > 0) {
        const searchBox = document.createElement("input");
        searchBox.type = "search";
        searchBox.id = "service-search";
        searchBox.placeholder = "Search for a service...";
        searchBox.setAttribute("aria-label", "Search services");

        const main = document.querySelector("main");

        if (main) {
            main.prepend(searchBox);

            const results = document.createElement("p");
            results.id = "search-results";
            results.setAttribute("aria-live", "polite");
            searchBox.insertAdjacentElement("afterend", results);

            searchBox.addEventListener("input", function () {
                let count = 0;
                const query = searchBox.value.trim().toLowerCase();

                serviceItems.forEach(function (item) {
                    const matches = item.textContent.toLowerCase().includes(query);
                    item.hidden = !matches;
                    if (matches) count++;
                });

                results.textContent = count +
                    (count === 1 ? " service found." : " services found.");
            });
        }
    }

    // 4. DARK MODE AND LIGHT MODE
    // One button, one implementation, and saved preferences.
    let themeButton = document.querySelector("#theme-toggle");

    if (!themeButton) {
        themeButton = document.createElement("button");
        themeButton.id = "theme-toggle";
        themeButton.type = "button";
        document.body.appendChild(themeButton);
    }

    themeButton.style.position = "fixed";
    themeButton.style.bottom = "20px";
    themeButton.style.left = "20px";
    themeButton.style.zIndex = "1000";

    try {
        if (localStorage.getItem("greenCutTheme") === "dark") {
            document.body.classList.add("dark-mode");
        } else {
            document.body.classList.remove("dark-mode");
        }
    } catch (error) {
        console.warn("Unable to load saved theme.");
    }

    function updateThemeButton() {
        const darkMode = document.body.classList.contains("dark-mode");

        themeButton.textContent = darkMode ? "☀️ Light Mode" : "🌙 Dark Mode";
        themeButton.setAttribute("aria-pressed", String(darkMode));
    }

    updateThemeButton();

    themeButton.addEventListener("click", function () {
        document.body.classList.toggle("dark-mode");

        const theme = document.body.classList.contains("dark-mode")
            ? "dark"
            : "light";

        try {
            localStorage.setItem("greenCutTheme", theme);
        } catch (error) {
            console.warn("Unable to save theme preference.");
        }

        updateThemeButton();
    });

    // 5. FORM VALIDATION
    document.querySelectorAll("form").forEach(function (form) {

        form.addEventListener("submit", function (event) {

            if (!form.checkValidity()) {
                event.preventDefault();
                form.reportValidity();
                return;
            }

            // CONTACT FORM
            if (form.id === "contact-form") {
                event.preventDefault();

                const name = form.querySelector('[name="name"]').value.trim();
                const email = form.querySelector('[name="email"]').value.trim();
                const phone = form.querySelector('[name="phone"]').value.trim();
                const message = form.querySelector('[name="message"]').value.trim();

                const subject = encodeURIComponent("GREEN CUT Website Contact Message");

                const body = encodeURIComponent(
                    "Name: " + name + "\n" +
                    "Email: " + email + "\n" +
                    "Phone: " + (phone || "Not provided") + "\n\n" +
                    "Message:\n" + message
                );

                window.location.href =
                    "mailto:info@greencut.co.za?subject=" +
                    subject + "&body=" + body;

                return;
            }

            // ENQUIRY FORM
            if (form.id === "enquiry-form") {
                event.preventDefault();

                const name = form.querySelector('[name="fullname"]').value.trim();
                const service = form.querySelector('[name="service"]').value;

                showFormResponse(
                    form,
                    "Thank you, " + name +
                    ". Your enquiry about " + service +
                    " has been validated. Please contact GREEN CUT to confirm " +
                    "availability and pricing. Your enquiry has not been sent."
                );

                return;
            }

            // BOOKING FORM
            if (form.id === "booking-form") {
                event.preventDefault();

                const dateInput = form.querySelector('[name="date"]');

                const today = new Date();
                const localToday = new Date(
                    today.getTime() - today.getTimezoneOffset() * 60000
                ).toISOString().split("T")[0];

                if (dateInput.value < localToday) {
                    dateInput.setCustomValidity(
                        "Please select today or a future date."
                    );
                    dateInput.reportValidity();
                    dateInput.setCustomValidity("");
                    return;
                }

                showFormResponse(
                    form,
                    "Your booking details have been validated. Please contact " +
                    "GREEN CUT to confirm your appointment. Your booking has " +
                    "not been sent or confirmed."
                );

                return;
            }

            event.preventDefault();

            alert("Your information has been validated but has not been sent.");
        });
    });

    // Display form responses without duplicating previous messages.
    function showFormResponse(form, message) {
        const parent = form.parentNode;
        const oldResponse = parent.querySelector(".form-response");

        if (oldResponse) {
            oldResponse.remove();
        }

        const response = document.createElement("div");
        response.className = "form-response";
        response.setAttribute("role", "status");
        response.textContent = message;

        form.insertAdjacentElement("afterend", response);
    }

    // 6. PREVENT PAST BOOKING DATES
    const bookingDate = document.querySelector('#booking-form input[type="date"]');

    if (bookingDate) {
        const today = new Date();

        bookingDate.min = new Date(
            today.getTime() - today.getTimezoneOffset() * 60000
        ).toISOString().split("T")[0];
    }

    // 7. TEXTAREA CHARACTER COUNTERS
    document.querySelectorAll("textarea").forEach(function (textarea) {
        const counter = document.createElement("p");

        counter.className = "character-counter";
        counter.textContent = "Characters: " + textarea.value.length;
        counter.setAttribute("aria-live", "polite");

        textarea.insertAdjacentElement("afterend", counter);

        textarea.addEventListener("input", function () {
            counter.textContent = "Characters: " + textarea.value.length;
        });
    });

    // 8. BACK TO TOP BUTTON
    const topButton = document.createElement("button");

    topButton.textContent = "↑ Back to Top";
    topButton.id = "back-to-top";
    topButton.type = "button";
    topButton.setAttribute("aria-label", "Back to top");

    document.body.appendChild(topButton);

    topButton.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    function updateTopButton() {
        topButton.classList.toggle("visible", window.scrollY > 300);
    }

    window.addEventListener("scroll", updateTopButton, { passive: true });
    updateTopButton();

    // 9. IMAGE LIGHTBOX
    document.querySelectorAll(".gallery img").forEach(function (image) {

        image.style.cursor = "zoom-in";

        image.addEventListener("click", function () {
            const overlay = document.createElement("div");
            overlay.className = "image-lightbox";
            overlay.setAttribute("role", "dialog");
            overlay.setAttribute("aria-modal", "true");
            overlay.setAttribute("aria-label", "Enlarged gallery image");

            const largeImage = document.createElement("img");
            largeImage.src = image.src;
            largeImage.alt = image.alt;

            const closeButton = document.createElement("button");
            closeButton.type = "button";
            closeButton.textContent = "×";
            closeButton.className = "lightbox-close";
            closeButton.setAttribute("aria-label", "Close image");

            overlay.appendChild(closeButton);
            overlay.appendChild(largeImage);
            document.body.appendChild(overlay);

            function closeLightbox() {
                overlay.remove();
                image.focus();
                document.removeEventListener("keydown", handleEscape);
            }

            function handleEscape(event) {
                if (event.key === "Escape") {
                    closeLightbox();
                }
            }

            closeButton.addEventListener("click", closeLightbox);

            overlay.addEventListener("click", function (event) {
                if (event.target === overlay) closeLightbox();
            });

            document.addEventListener("keydown", handleEscape);
            closeButton.focus();
        });
    });

    // 10. FAQ ACCORDION
    document.querySelectorAll(".faq-question").forEach(function (question) {

        question.setAttribute("aria-expanded", "false");

        question.addEventListener("click", function () {
            const answer = question.nextElementSibling;

            if (answer && answer.classList.contains("faq-answer")) {
                answer.hidden = !answer.hidden;

                question.setAttribute(
                    "aria-expanded",
                    String(!answer.hidden)
                );
            }
        });
    });

    // 11. AUTOMATIC FOOTER YEAR
    document.querySelectorAll("#current-year").forEach(function (year) {
        year.textContent = new Date().getFullYear();
    });

    // 12. PRINT PAGE
    const printButton = document.createElement("button");

    printButton.textContent = "Print Page";
    printButton.id = "print-page";
    printButton.type = "button";

    document.body.appendChild(printButton);

    printButton.addEventListener("click", function () {
        window.print();
    });

    // 13. SCROLL PROGRESS BAR
    const progress = document.createElement("div");

    progress.id = "scroll-progress";
    progress.setAttribute("aria-hidden", "true");

    document.body.appendChild(progress);

    function updateProgress() {
        const totalHeight =
            document.documentElement.scrollHeight - window.innerHeight;

        const percentage = totalHeight > 0
            ? (window.scrollY / totalHeight) * 100
            : 0;

        progress.style.width = percentage + "%";
    }

    window.addEventListener("scroll", updateProgress, { passive: true });
    window.addEventListener("resize", updateProgress);
    updateProgress();

    console.log("GREEN CUT JavaScript loaded successfully!");

});